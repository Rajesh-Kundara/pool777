# TODOs

- Proper resource examples - [SAMPLES.md](SAMPLES.md)
- Tests
- Paystack Exception Classes and throwing
