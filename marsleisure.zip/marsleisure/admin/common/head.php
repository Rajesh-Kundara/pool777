<head>
	<meta charset="utf-8">
	<link rel="icon" href="../assets/images/logo.png" sizes="16x16">
	<title>Admin Portal</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="../image/png" href="favicon.ico">
	<link href="../login/css/googleFont.css" rel="stylesheet">
	<!--<link rel="stylesheet" href="../assets/css/owl.carousel.html"> 
	<link rel="stylesheet" href="../assets/css/owl.theme.html"> 
	<link rel="stylesheet" href="../assets/css/slick/slick.css"> 
	<link rel="stylesheet" href="../assets/css/slick/slick-theme.css">
	<link rel="stylesheet" href="../assets/css/animate.css">
	<link rel="stylesheet" href="../assets/css/iconfont.css">
	<link rel="stylesheet" href="../assets/css/font-awesome.min.css">-->
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<!--<link rel="stylesheet" href="../assets/css/magnific-popup.css">
	<link rel="stylesheet" href="../assets/css/bootsnav.css">-->
	<link rel="stylesheet" href="../assets/css/style.css">
	<!--<link rel="stylesheet" href="../assets/css/responsive.css" />
	<script src="../assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>-->
	
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="../assets/css/bootstrap-material-datetimepicker.css">
	
	<script>
		var rootPath="http://localhost:8008/marsleisure";
		//var rootPath="";
	</script>
</head>

