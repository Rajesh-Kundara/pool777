
<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default navbar-fixed-top">
	<div class="container-fluid"> 
		<div class="navbar-header">
			<!--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
				<i class="fa fa-bars"></i>
			</button>-->
			<a class="navbar-brand" href="../index.php">
				<img alt="Brand" src="../assets/images/logo.png" style="height:100px;widht:100px">
			</a>
		</div>
		<div class="navbar-collapse" id="navbar-menu" align="center">
			<ul class="nav nav-tabs navbar-nav mr-auto">
				<li role="presentation"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
				<li role="presentation" class="active"><a class="nav-link" href="users.php">Clients</a></li>
				<li role="presentation"><a class="nav-link" href="coupons.php">Coupons</a></li>
				<li role="presentation"><a class="nav-link" href="matches.php">Matches</a></li>
				<!--<li role="presentation"><a class="nav-link" href="rules.php">Expert Rules</a></li>
				<li role="presentation"><a class="nav-link" href="tips.php">Free Tips</a></li>
				<li role="presentation"><a class="nav-link" href="premium-tips.php">Premium Tips</a></li>
				<li><a href="contacts.php">Premium Contacts</a></li>-->
				<li role="presentation"><a class="nav-link" href="index.php?action=logout">Logout</a></li>
			</ul>
		</div>
		<div class="alert alert-info" style="width:350px">
		  <strong>Work in progress :</strong> Many functionalities are not supposed to work. Thanks for your patience.
		</div>
	
	</div> 
	
</nav><!--<span>Welcome <?=$_COOKIE['fullname']?></span>-->
