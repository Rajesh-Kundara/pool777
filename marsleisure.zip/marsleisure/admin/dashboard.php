<?php 
include('../common/config.php');
if($_COOKIE['fullname'] == '')
{
	echo "<script>window.location.href='index.php?q=error'</script>";
}
?>

<html class="no-js" lang="en">
<?php 
include('common/head.php');
	
if($_GET['edit'] == ''){
?>

<?php 
ini_set("display_errors","off");
if(!empty($_POST['saveButton']))
{
	$id="0";
	if(!empty($_POST['idForUpdate'])){
		$id=$_POST['idForUpdate'];
	}
	$message=$_POST['message'];
	
	if($id=="0"){
		$sql = "insert into greetings(text) values('$message')";	
	}else{
		$sql = "update greetings set text='$message' where id=$id";	
	}
	//echo $sql;die;
	$result = mysql_query($sql);
	$idValue = mysql_insert_id();

	echo "<script>window.location.href='dashboard.php'</script>";
}
?>
	
    <body data-spy="scroll" data-target=".navbar-collapse">
        <div class="culmn">
			<?php include('common/header.php'); ?>


            <!--Test section-->
            <section id="test" class="test roomy-60 fix">
                <div class="container containerClass">
                    <div class="row">                        
                        <div class="main_test fix">
							<div class="col-md-2"></div>
                            <div class="col-md-8">
                                <div class="test_item fix">
									<form method="post" enctype="multipart/form-data" >
									<div class="row">
										<div class="col-md-4"></div>
										<div class="col-md-4"><h4><u>Dashboard</u></h4></div>
										<div class="col-md-4"></div>
									</div><br>
									<?php 
										$sql = "SELECT * FROM greetings order by id desc limit 1";
										$stmt3 = mysql_query($sql);
										$text="";
										//echo mysql_error();
										if ( $stmt3 ){ 
											while( $row3 = mysql_fetch_array( $stmt3)){ 
												$text=$row3['text'];
											}
										}				
									?>
                                    <div class="row">
										<div class="col-md-3">
											<h5 style="padding:10px 12px 12px 0;display: inline-block;">Ticker message</h5>
										</div>
										<div class="col-md-7">
											<input type="text" class="form-control input-sm" name="message" value="<?=$text?>" placeholder="greeting message..." required>
										</div>
									</div>
									<!--<div class="row">
										<div class="col-md-3">
											<h5 style="padding:10px 12px 12px 0;display: inline-block;">Description</h5>
										</div>
										<div class="col-md-7">
											<textarea name="description" placeholder="description..." style="height:116px;" required></textarea>
										</div>
									</div><br>
									<div class="row">
										<div class="col-md-3">
											<h5 style="padding:10px 12px 12px 0;display: inline-block;">Media</h5>
										</div>
										<div class="col-md-7">
											<input type="file" name="file[]" multiple="multiple">
										</div>
									</div><br>-->
									
									<!--<div class="row">
										<div class="col-md-3">
											<h5 style="padding:10px 12px 12px 0;display: inline-block;">Target(Date&Time)</h5>
										</div>
										<div class="col-md-3">
											<input type="text" name="tdate" class="datepicker1" id="todate" placeholder="Date" required>
										</div>
										<div class="col-md-3">
											<input type="text" name="ttime" id="timepicker" placeholder="Time" required>
										</div>
									</div><br>-->
									
									<div class="row">
										<div class="col-md-5"></div>
										<div class="col-md-4">
											<input type="submit" name="saveButton" value="Save" class="btn btn-primary">	
										</div>	
										<div class="col-md-3"></div>
									</div>
									</form>
                                </div>
                            </div>
							<div class="col-md-2"></div>
                        </div>
                    </div>
                </div>
            </section><!-- End off test section -->




                <div class="main_footer fix bg-mega text-center p-top-40 p-bottom-30 m-top-80">
                    <div class="col-md-12">
                        <p class="wow fadeInRight" data-wow-duration="1s">
                            Admin Portal
                        </p>
                    </div>
                </div>




        </div>

        <!-- JS includes -->

        <script src="../assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="../assets/js/vendor/bootstrap.min.js"></script>
		
        <script src="../assets/js/owl.carousel.min.html"></script>
        <script src="../assets/js/jquery.magnific-popup.js"></script>
        <script src="../assets/js/jquery.easing.1.3.js"></script>
        <script src="../assets/css/slick/slick.js"></script>
        <script src="../assets/css/slick/slick.min.js"></script>
        <script src="../assets/js/jquery.collapse.js"></script>
        <script src="../assets/js/bootsnav.js"></script>

        <script src="../assets/js/plugins.js"></script>
        <script src="../assets/js/main.js"></script>
		<link href="../assets/css/jquery.multiselect.css" rel="stylesheet" type="text/css">
		<script src="../assets/js/jquery.multiselect.js"></script>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<link rel="stylesheet" href="../resources/demos/style.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
		
		<script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script>
		<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>
		<script src="../assets/js/mdtimepicker.js"></script>
		<link href="../assets/css/mdtimepicker.css" rel="stylesheet" type="text/css">
		
<script>
  $(document).ready(function(){
    $('#timepicker').mdtimepicker(); //Initializes the time picker
  });
</script>
<script>		
$(function(){
	$( ".datepicker1" ).datepicker({ 
		dateFormat: 'dd-mm-yy',
		minDate: 0		
	}).val();
});
</script>
<script>
$(".chosen-select").chosen({
  no_results_text: "Oops, nothing found!"
});
</script>
<script>
$(":radio").change(function(){
	var teamValue = jQuery('input[name=team]:checked').val();
	$.ajax({
	 type : 'post',
	 url : 'memberNameValue.php',
	 data : {teamValue:teamValue},
	success : function(data)
	{
		$('#members').html(data);
	}
	});
});	
</script>
		
		
    </body>
<?php }else{ ?>

<body data-spy="scroll" data-target=".navbar-collapse">
        <div class="culmn">
			<?php include('header.php'); ?>
		
<?php 
$sql = "select * from Tip where id = '".$_GET['edit']."'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
?>
<?php 
if(isset($_POST['update']))
{
	extract($_POST);
	$sSql = "update Tip set title = '$title' , description = '$description' , datetime = 'now()' where id = '".$_GET['edit']."'";
	$sResult = mysql_query($sSql);

	$rSql = "insert into history(title,description,assignto,media,datetime,assignby,type,status,Tipid)values('$title','$description','".$row['assignto']."','".$row['media']."',now(),'".$_COOKIE['id']."','Tip','Edit','".$_COOKIE['id']."')";
	$rResult = mysql_query($rSql);
	
	echo "<script>window.location.href='dashboard.php'</script>";
}
?>	
            <!--Test section-->
            <section id="test" class="test roomy-60 fix">
                <div class="container" style="margin-top: 3%;">
                    <div class="row">                        
                        <div class="main_test fix">
							<div class="col-md-2"></div>
                            <div class="col-md-8">
                                <div class="test_item fix">
									<form method="post" >
										<div class="row">
											<div class="col-md-4"></div>
											<div class="col-md-4"><h4><u>Edit Tip</u></h4></div>
											<div class="col-md-4"></div>
										</div><br>
										<div class="row">
											<div class="col-md-3">
												<h5 style="padding:10px 12px 12px 0;display: inline-block;">Tip title</h5>
											</div>
											<div class="col-md-7">
												<input type="text" name="title" placeholder="Title" value="<?php echo $row['title']?>" required>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<h5 style="padding:10px 12px 12px 0;display: inline-block;">Tip description</h5>
											</div>
											<div class="col-md-7">
												<textarea name="description" placeholder="Description" style="height:116px;" required><?php echo $row['description']?></textarea>
											</div>
										</div><br>
										<!--<div class="row">
											<div class="col-md-3">
												<h5 style="padding:10px 12px 12px 0;display: inline-block;">Media</h5>
											</div>
											<div class="col-md-7">
												<input type="file" name="file[]" multiple="multiple">
											</div>
										</div><br>-->
										<div class="row">
											<div class="col-md-3">
												<h5>Copy to</h5>
											</div>
											<div class="col-md-7">
												<link href="assets/css/jquery.multiselect.css" rel="stylesheet" type="text/css">
												<script src="assets/js/jquery.multiselect.js"></script>
												<select name="copy[]" id="copy" style="padding:5px;" multiple="multiple">
												<?php
													$pSql = "select * from users where type = '2' and id != '".$_COOKIE['id']."'";
													$pResult = mysql_query($pSql);
													while($pRow = mysql_fetch_array($pResult)){
												?>
												<option value="<?php echo $pRow['id']?>">  <?php echo $pRow['name'];?>  </option>
												<?php } ?>
												</select>
											</div>
											<script>
											$('#copy').multiselect({
												columns: 1,
												placeholder: 'Select name'
											});
											</script>
										</div><br>
										<div class="row">
											<div class="col-md-5"></div>
											<div class="col-md-4">
												<input type="submit" name="update" value="Update" class="btn btn-primary">	
											</div>	
											<div class="col-md-3"></div>
										</div>
									</form>
                                </div>
                            </div>
							<div class="col-md-2"></div>
                        </div>
                    </div>
                </div>
            </section><!-- End off test section -->




                <div class="main_footer fix bg-mega text-center p-top-40 p-bottom-30 m-top-80">
                    <div class="col-md-12">
                        <p class="wow fadeInRight" data-wow-duration="1s">
                            CrickExpert Portal
                        </p>
                    </div>
                </div>




        </div>

        <!-- JS includes -->

        <script src="../assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="../assets/js/vendor/bootstrap.min.js"></script>
		
        <script src="../assets/js/owl.carousel.min.html"></script>
        <script src="../assets/js/jquery.magnific-popup.js"></script>
        <script src="../assets/js/jquery.easing.1.3.js"></script>
        <script src="../assets/css/slick/slick.js"></script>
        <script src="../assets/css/slick/slick.min.js"></script>
        <script src="../assets/js/jquery.collapse.js"></script>
        <script src="../assets/js/bootsnav.js"></script>



        <script src="../assets/js/plugins.js"></script>
        <script src="../assets/js/main.js"></script>

<?php } ?>
</html>
