<?php
include('../config.php');
$userId='';
$name="Guest";
$email='';
$mobile='';
$address='';
if(!empty($_POST['id']) && !empty($_POST['status'])){
	$response=array();
				
	$id=$_POST['id'];
	$status=$_POST['status'];
	
	$tsql = "UPDATE tips set imageStatus='$status' WHERE id='$id'";  
	
	$stmt = mysql_query( $tsql);  
	$insertId = mysql_insert_id();
	if ( $stmt )  
	{  
		$response['status']="Success";
		$response["message"] = "Data updated succefully.";
	}   
	else{  
		$response['status'] ="Failure";
		$response["message"] = "Error: ".mysql_error();
	}    
	
}else{
	$response['status'] ="Failure";
	$response["message"] = "Parameter(s) missing!";
}

echo json_encode($response);
?>