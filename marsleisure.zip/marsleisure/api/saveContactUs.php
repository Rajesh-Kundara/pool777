<?php
include('../config.php');
$userId='';
$name="Guest";
$email='';
$mobile='';
$address='';
if(!empty($_POST['name']) && !empty($_POST['phone']) && !empty($_POST['plan'])){
	$response=array();
				
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$plan=$_POST['plan'];
	
	$tsql = "INSERT INTO contacts (name,phone,plan,date) VALUES ('$name','$phone','$plan',NOW())";  
	
	$stmt = mysql_query( $tsql);  
	$insertId = mysql_insert_id();
	if ( $stmt )  
	{  
		$response['success']=1;
		$response["message"] = "We will contact you back as soon as possible.";
	}   
	else{  
		$response['success'] =0;
		$response["message"] = "Error: ".mysql_error();
	}    
	
}else{
	$response['success'] =0;
	$response["message"] = "Parameter(s) missing!";
}

echo json_encode($response);
?>