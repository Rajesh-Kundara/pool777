<?php
include('../common/config.php');
if(!empty($_POST['winner']) && !empty($_POST['idForUpdate'])){
	$response=array();
		
	$idForUpdate=$_POST['idForUpdate'];
	$winner=$_POST['winner'];
	$homeScore=$_POST['homeScore'];
	$awayScore=$_POST['awayScore'];
	
	$isResultDeclared=0;
	$isHomeWinner=0;
	$isAwayWinner=0;
	$winnerInStack=-1;
	switch($winner){
		case "H": 
			$isResultDeclared=1;
			$isHomeWinner=1;
			$isAwayWinner=0;
			$winnerInStack=1;//home
			break;
		case "A": 
			$isResultDeclared=1;
			$isHomeWinner=0;
			$isAwayWinner=1;
			$winnerInStack=2;//away
			break;
		case "D": 
			$isResultDeclared=1;
			if($homeScore>0 && $awayScore>0){
				$isHomeWinner=1;
				$isAwayWinner=1;
			}else{
				$isHomeWinner=0;
				$isAwayWinner=0;
			}
			$winnerInStack=0;//draw
			break;
		case "N"://not declared 
			$isResultDeclared=0;
			$isHomeWinner=0;
			$isAwayWinner=0;
			$winnerInStack=-1;//not declared
			break;
	}
	$sql = "UPDATE matches set isResultDeclared='$isResultDeclared',isHomeWinner='$isHomeWinner',
			homeScore='$homeScore',awayScore='$awayScore',isAwayWinner='$isAwayWinner' WHERE id='$idForUpdate'";  

	$stmt = mysql_query( $sql);  
	if ( $stmt )  
	{  
		$sql = "UPDATE stackdetail set winner=$winnerInStack WHERE matchId='$idForUpdate'";  

		$stmt = mysql_query( $sql);  
		if ( $stmt )  
		{ 
		}
		$response['success']="1";
		$response["message"] = "Data saved succefully.";
	}   
	else{  
		$response['success'] ="0";
		$response["message"] = "Error: ".mysql_error();
	}    
	
}else{
	$response['success'] ="0";
	$response["message"] = "Parameter(s) missing!";
}

echo json_encode($response);
?>