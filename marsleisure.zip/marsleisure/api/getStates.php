<?php
include ('../common/config.php');
$response=array();
$response['statesList']=array();
if(!empty($_POST['countryId'])){
	$sql = "SELECT * FROM states WHERE country_id='".$_POST['countryId']."' AND name!=''";
	$stmt = mysql_query($sql);
	
	if ( $stmt ){
		while( $row = mysql_fetch_array( $stmt)){
				$data=array();
				$data['id']=$row['id'];
				$data['name']=$row['name'];
				
				array_push($response['statesList'],$data);
			} 
			$response['success'] =1;
			$response["message"] = "Data list loading successful.";				
	}else{  
		$response['success'] =0;
		$response["message"] = "Something went wrong.".mysql_error();  
	} 
	}else{
		$response['success'] =0;
		$response["message"] = "Parameters missing!.";	
	}
		
	echo json_encode($response);			
?>