<?php
include('../common/config.php');
if(!empty($_POST['homeTeam']) && !empty($_POST['awayTeam'])){
	$response=array();
	$isUpdate=false;
	if(!empty($_POST['idForUpdate'])){
		$isUpdate=true;
		$idForUpdate=$_POST['idForUpdate'];
	}
	$leagueId=$_POST['leagueId'];
	$league=$_POST['league'];
	$season=$_POST['season'];
	$week=$_POST['week'];
	$homeTeam=$_POST['homeTeam'];
	$awayTeam=$_POST['awayTeam'];
	$matchDate=$_POST['matchDate'];
	
	if($isUpdate){
		$sql = "UPDATE matches set leagueId='$leagueId',league='$league',season='$season',week='$week',homeTeam='$homeTeam',awayTeam='$awayTeam',
				matchDate='$matchDate' WHERE id='$idForUpdate'";  
	}else{
		$sql = "INSERT INTO matches (leagueId,league,season,week,homeTeam,awayTeam,matchDate)
				VALUES('$leagueId','$league','$season','$week','$homeTeam','$awayTeam',NOW())";  
	}
	$stmt = mysql_query( $sql);  
	$insertId = mysql_insert_id();
	if ( $stmt )  
	{  
		$response['success']="1";
		$response["message"] = "Data saved succefully.";
	}   
	else{  
		$response['success'] ="0";
		$response["message"] = "Error: ".mysql_error();
	}    
	
}else{
	$response['success'] ="0";
	$response["message"] = "Parameter(s) missing!";
}

echo json_encode($response);
?>