<?php
include ('../config.php');
$response=array();
$response['dashboardData']=array();
	$sql = "SELECT * FROM greetings order by id desc limit 1";
	$stmt = mysql_query($sql);
	
	$response['greetingText']="Welcome!";
	$response['adImageUrl']="";
	$response['adText']="";
	$response['adRedirectUrl']="";
	//echo mysql_error();
	if ( $stmt ){ 
		while( $row = mysql_fetch_array( $stmt)){ 
			$response['greetingText']=$row['text'];
		}
	}
	
	$sql = "SELECT * FROM ads order by id desc limit 1";
	$stmt3 = mysql_query($sql);
	
	//echo mysql_error();
	if ( $stmt3 ){ 
		while( $row = mysql_fetch_array( $stmt3)){ 
			$response['adText']=$row['text'];
			$response['adImageUrl']=$row['imageUrl'];
			$response['adRedirectUrl']=$row['redirectUrl'];
		}
	}
	$response['success']=1;
	$response['message']="Welcome!";	
	echo json_encode($response);			
?>