<?php
include('../common/config.php');
if(!empty($_POST['for'])){
	$response=array();
		
	$for=$_POST['for'];
	$userId=$_SESSION['id'];
	switch($for){
		case "personal":
			$middleName=$_POST['middleName'];
			$company=$_POST['company'];
			$email=$_POST['email'];
			$phone=$_POST['phone'];
			$phone_gsm=$_POST['phone_gsm'];
			$zipcode=$_POST['zipcode'];
			$countryId=$_POST['countryId'];
			$stateId=$_POST['stateId'];
			$street=$_POST['street'];
			
			$sql = "UPDATE users set m_name='$middleName',company='$company', email='$email',phone='$phone',
					phone_gsm='$phone_gsm', zipcode='$zipcode', countryId='$countryId', stateId='$stateId', street='$street' WHERE id='$userId'";  
			break;
		case "account":
			$prefCurrency=$_POST['prefCurrency'];
			$bankCountry=$_POST['bankCountry'];
			$bankName=$_POST['bankName'];
			$branch=$_POST['branch'];
			$accountNo=$_POST['accountNo'];
			$accountName=$_POST['accountName'];
			$iban=$_POST['iban'];
			$bankBeneficier=$_POST['bankBeneficier'];
			
			$sql = "UPDATE users set prefCurrency='$prefCurrency',bankCountry='$bankCountry', bankName='$bankName',
					branch='$branch', accountNo='$accountNo', accountName='$accountName', iban='$iban', 
					bankBeneficier='$bankBeneficier' WHERE id='$userId'";  
			break;
		case "password":
			$oldPassword=$_POST['oldPassword'];
			$reNewPassword=$_POST['reNewPassword'];
			
			$sql = "UPDATE users set password='$reNewPassword' WHERE id='$userId' AND password='$oldPassword'";  
			break;
	}
	
	$stmt = mysql_query( $sql);  
	$affected_rows = mysql_affected_rows();
	if ( $stmt )  
	{  
		if($for=="password" && $affected_rows==0){
			$response['success']="0";
			$response["message"] = "Wrong old password!";
		}else{
			$response['success']="1";
			$response["message"] = "Detail successfuly updated.";
		}
	}   
	else{  
		$response['success'] ="0";
		$response["message"] = "Error: ".mysql_error();
	}    
	
}else{
	$response['success'] ="0";
	$response["message"] = "Parameter(s) missing!";
}

echo json_encode($response);
?>