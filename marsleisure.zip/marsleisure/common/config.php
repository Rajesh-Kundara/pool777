<?php
session_start();
$whitelist = array('127.0.0.1','::1','192.168.43.43','192.168.1.101:8180','52.221.253.111');
 
 if(!in_array($_SERVER['SERVER_ADDR'], $whitelist)){
	 //$hostname="http://".$_SERVER['HTTP_HOST'];
	 $hostname="";
	 $db_host="db-loctown.cfobhgohtqs9.ap-south-1.rds.amazonaws.com:3306";
	 //$dbu="tharwayc_admin";
	 $dbu="adminloctown";
	 //$db_sec="tharberry971";
	 $db_sec="Chaman971";
	 //$db_name="tharwayc_tharberry";
	 $db_name="marsleisure";
	 
	 $rootPath="";
 }else{
	 $hostname="/marsleisure";
	 $db_host="localhost";
	 $dbu="root";
	 $db_sec="";
	 $db_name="marsleisure";
 }

 //SMS configuration
 $sms_url='';
 $sms_uname='';
 $sms_pass='';
 $sms_sender_id='';
 //SMS configuration-END
 
 //EMail configuration
 $mail_host='';
 $mail_port='465';
 $mail_username='';
 $mail_password='';
 $mail_from='';
 //EMail configuration-END
 
 // This is the single point entry for the database connection on server
 mysql_connect($db_host,$dbu,$db_sec) or die(mysql_error()." NO CONNECTION FOUND ");

 //$connection = mysqli_connect($db_host,$dbu,$db_sec,$db_name) or die(mysqli_error($connection));
 
 // Database Name for the server
 mysql_select_db($db_name) or die(mysql_error()."NO DB FOUND");
 
 
mysql_query('SET character_set_results=utf8');
mysql_query('SET names=utf8');
mysql_query('SET character_set_client=utf8');
mysql_query('SET character_set_connection=utf8');
mysql_query('SET character_set_results=utf8');
mysql_query('SET collation_connection=utf8_general_ci');
 // Turn off all error reporting
 //error_reporting(0);

// Report simple running errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);

function lastInsertId($queryID) {
    sqlsrv_next_result($queryID);
    sqlsrv_fetch($queryID);
    return sqlsrv_get_field($queryID, 0);
}
?>