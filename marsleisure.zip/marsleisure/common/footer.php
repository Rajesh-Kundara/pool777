<div class="px-4 py-4  fix bg-dark text-center">
	<div class="row" >
		<div class="" style="display:block;margin-left: auto;margin-right: auto;">
			<ul class="">
				<li style="float: left;"><a class="text-light" href="game.php">Stack</a> <span class="text-muted px-2">|</span></li>
				<li style="float: left;"><a class="text-light" href="result.php">Result</a> <span class="text-muted px-2">|</span></li>
				<li style="float: left;"><a class="text-light" href="calculate_winning.php">About Us</a> <span class="text-muted px-2">|</span></li>
				<li style="float: left;"><a class="text-light" href="contact_us.php">Contact Us</a> <span class="text-muted px-2">|</span></li>
				<li style="float: left;"><a class="text-light" href="calculate_winning.php">Calculate Winning</a></li>
			</ul>
		</div>
	</div>
</div>