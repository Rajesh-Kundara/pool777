
<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default navbar-fixed-top">
	<div class="container-fluid"> 
		<div class="navbar-header">
			<!--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
				<i class="fa fa-bars"></i>
			</button>-->
			<a class="navbar-brand" href="dashboard.php">
				<img alt="Brand" src="assets/images/logo.png" style="height:100px;widht:100px">
			</a>
		</div>
		<div class="navbar-collapse" id="navbar-menu" align="center">
			<ul class="nav nav-tabs navbar-nav mr-auto">
				<li role="presentation"><a class="nav-link" href="index.php">Stack</a></li>
				<li role="presentation"><a class="nav-link" href="#">Results</a></li>
				<li role="presentation" class="active"><a class="nav-link" href="about_us.php">About Us</a></li>
				<li role="presentation"><a class="nav-link" href="#">Contact Us</a></li>
			</ul>
			<?php
			if(!empty($_GET['logout'])){
				$_SESSION['fullname']=null;
				session_destroy();
				header('index.php');
			}
			if(!isset($_SESSION['fullname'])){
			?>
			<div class="dropdown" style="float:right;width:250px">
				<button id="dLabel" class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Login/Register
				</button>
				<div class="dropdown-menu dropdown-menu-right" aria-labelledby="dLabel">
				  <form class="px-4 py-1">
					<div class="form-group">
					  <label for="userName">Username</label>
					  <input type="text" class="form-control" id="userName" placeholder="userName">
					</div>
					<div class="form-group">
					  <label for="password">Password</label>
					  <input type="password" class="form-control" id="password" placeholder="Password">
					</div>
					<div class="form-check">
					  <input type="checkbox" class="form-check-input" id="dropdownCheck">
					  <label class="form-check-label" for="dropdownCheck">
						Remember me
					  </label>
					</div>
					<button type="button" onClick="login()" class="btn btn-primary">Sign in</button>
					
				  </form>
				  <div id="loginErrorContainer"></div>
				  <div class="dropdown-divider"></div>
				  <a class="dropdown-item" href="<?=$hostname;?>/register.php">New around here? Sign up</a>
				  <!--<a class="dropdown-item" href="#">Forgot password?</a>-->
				</div>
			</div>
			<?php
			}else{
				$sql = "SELECT SUM(amount) as balance from balance WHERE userId=".$_SESSION['id'];  
				$result = mysql_query( $sql);  
				if ( $result ){  
					$row = mysql_fetch_array($result);
					$balance = $row['balance'];
				}
			?>
			<div class="badge badge-light" style="width:250px;">
			Welcome <?=$_SESSION['fullname']?> <a href="?logout=rdr">(logout)</a></br></br>
			Balance : <?=$balance?> &#8358;
			</div>
				<div class="">
					<ul class="">
					  <li class="">
						<a class="text-dark" href="account.php">My Account</a>
					  </li>
					  <?php 
					  if($_SESSION['type']=="A"){
						?>
					  <li class="">
						<a class="text-dark" href="<?=$hostname?>/admin/dashboard.php">Admin Panel</a>
					  </li>
					  <?php } ?>
					</ul>
				</div>
			<?php
			}
			?>
		</div> 
	</div>
	
	<div class="alert alert-info alert-dismissible pr-0" style="width:400px;">
	  <strong>Work in progress!</strong> Thanks for your patience. Last updated : 12-05-2019
	  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	  </button>
	</div>
	
</nav><!--<span>Welcome <?=$_COOKIE['fullname']?></span>-->
