<?php 
include('common/config.php');
if($_COOKIE['fullname'] == '')
{
	//echo "<script>window.location.href='index.php?q=error'</script>";
}
?>

<html class="no-js" lang="en">
<?php 
include('common/head.php');

?>

<?php 
ini_set("display_errors","on");
if(!empty($_POST['saveButton']) || !empty($_POST['updateButton']))
{
	$id="0";
	if(!empty($_POST['idForUpdate'])){
		$id=$_POST['idForUpdate'];
	}
	$itemText=$_POST['itemText'];
	
	if($id=="0"){
		$sql = "insert into rules(text,date) values('$itemText',NOW())";	
	}else{
		$sql = "update rules set text='$itemText',date=NOW() where id=$id";	
	}
	//echo $sql;die;
	$result = mysql_query($sql);
	$idValue = mysql_insert_id();

	echo "<script>window.location.href='rules.php'</script>";
}
?>	
	
<body data-spy="scroll" data-target=".navbar-collapse">
<?php include('common/header.php'); ?>
<div class="culmn">
	
	<!--Test section-->
	<section id="test" class="test roomy-60 fix">
		<div class="container containerClass">
			<div class="row">                        
				<div class="main_test fix">
					<div class="col-md-12">
						<div class="test_item fix">
						<?php	
						$sql = "SELECT id,typeId,(SELECT name FROM coupontypemaster WHERE id=typeId) as name,minStack,minPerLine,ruleDescription,season,matchDate,closeDate,couponId,week,weekInfo,status FROM coupons WHERE status='A'";
						$stmt = mysql_query($sql);
						//echo mysql_error();
						$count=0;
						$itemCountInRow=0;
						if ( $stmt){
							while( $row = mysql_fetch_array( $stmt)){
								$name=explode(" - ",$row['name']);
								$name1=$row['name'];
								$name2="";
								if(sizeof($name)>1){
									$name1=$name[0];
									$name2=$name[1];
								}
								
								if($count%5==0){
									$itemCountInRow=0;
									$string=$string.'<div style="display: flex;flex-direction: row;">';
								}
								$string=$string.
										'<div onClick="window.location.href=\'game.php?coupon='.$row['couponId'].'\';" class="card bg-light mb-3" style="max-width: 12rem;margin:10px;cursor:pointer;">
											<img style="float:left;" class="card-img" src="images/super-7.jpg" alt="Card image">
											<div style="float:right;">
												<div class="card-header text-center p-2" >'.$name1.'</div>
												<div class="card-body p-2">
													<h5 class="card-title text-center">'.$name2.'</h5>
													<p class="card-text text-center">Coupon closes '.gmdate('l H:i e', strtotime($row['closeDate'])).'</p>
													<p class="card-text"><small class="text-muted"><b>Season :</b> '.$row['season'].' <b>Week no.</b> '.$row['week'].'</small></p>
												</div>
											</div>
										</div>';
								
								$itemCountInRow++;
								if($itemCountInRow==5){
									$string=$string.'</div>';
								}
								$count++;
							}
						}				
						if($itemCountInRow<5){
							$string=$string.'</div>';
						}
						echo $string;
						?>
						</div>
						<div class="col-md-2"></div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- End off test section -->

<?php include('common/footer.php'); ?>
</div>
<div id="couponDetailModel" class="modal fade" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard=false aria-labelledby="myModalLabel" aria-hidden="true">
	
	<div class="modal-dialog modal-lg" role="document" style="width:100%">
   		<div class="modal-content">
   			<div class="modal-header bg-info" >
       			<div class="modal-title" style="color: #196780;">
       				<div class="text-white" >
       					<b>Add New Coupon Detail</b> <span id="tokenNoSpan1"></span>
       				</div>
       			</div>  
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      		</div>
   			<div class="modal-body" id="customerServiceRequestModal_body">
	 			<div class="form-horizontal" role="form" >
	 			<table width="100%">
	 			
	 				<tr id="statusMarkCompletedDiv">
	 					<td colspan="3" class="col-md-12">
	 						<div class="col-md-12">
	 						<table width="100%">
	 							<tr>
	 								<td width="20%">&nbsp;</td>
	 								<td width="20%">&nbsp;</td>
	 								<td width="20%">&nbsp;</td>
	 								<td width="20%">&nbsp;</td>
	 								<td width="20%">&nbsp;</td>
	 							</tr>
	 							<tr>
	 								<td colspan="5">
	 									<table width="100%">
		 									<tr>
		 										<td width="100%">
		 											
		 										</td>
		 										</tr>
		 										<tr>
		 										<td width="100%">
		 											<table width="100%" class="panel panel-info" style="padding:10px;border-collapse:initial;">
		 												
							 							<tr>
							 								<td width="30%">Week :</td>
							 								<td width="70%">
																<select id="weekNo" name="weekNo" class="form-control">
																	<option value="0">Select</option>
																	<option value="1">Week 1</option>
																	<option value="2">Week 2</option>
																	<option value="3">Week 3</option>
																	<option value="4">Week 4</option>
																	<option value="5">Week 5</option>
																	<option value="6">Week 6</option>
																	<option value="7">Week 7</option>
																	<option value="8">Week 8</option>
																	<option value="9">Week 9</option>
																	<option value="10">Week 10</option>
																</select>
															</td>
							 							</tr>
														<tr>
							 								<td width="30%">Week info :</td>
							 								<td width="70%">
																<input type="text" id="weekInfo" class="form-control input-sm" placeholder="Week info..."/>
															</td>
							 							</tr>
														<tr>
							 								<td width="30%">Coupon Type :</td>
							 								<td width="70%">
																<select id="typeId" name="typeId" class="form-control">
																	<option value="0">Select</option>
																	<option value="1">Super 7</option>
																	<option value="2">Home Wins</option>
																	<option value="3">Away Wins</option>
																	<option value="4">General Draws</option>
																	<option value="5">Score Draws</option>
																	<option value="6">Treble Chance</option>
																	<option value="7">Fixed Odds A</option>
																	<option value="8">Fixed Odds B</option>
																	<option value="9">1 to 10 Draws</option>
																	<option value="10">1 to 9 Draws</option>
																</select>
															</td>
							 							</tr>
														<tr>
							 								<td width="30%">Minimum Stack :</td>
							 								<td width="70%">
																<div class="input-group">
																	<input type="text" id="minStack" class="form-control input-sm" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Minimum stack"/>
																	<div class="input-group-append">
																		<span class="input-group-text">&#8358;</span>
																	</div>
																</div></td>
							 							</tr>
														<tr>
							 								<td width="30%">Minimum Per-Line :</td>
							 								<td width="70%">
																<div class="input-group">
																	<input type="text" id="minPerLine" class="form-control input-sm" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Minimum per-line"/>
																	<div class="input-group-append">
																		<span class="input-group-text">&#8358;</span>
																	</div>
																</div></td>
							 							</tr>
							 							<tr>
							 								<td width="30%">Season :</td>
							 								<td width="70%"><input type="text" id="season" class="form-control input-sm" placeholder="Enter season name..."/></td>
							 							</tr>
														<tr>
							 								<td width="30%">Match Date :</td>
							 								<td width="70%">
																<input type="text" id="matchDate" class="form-control input-sm" placeholder="yyyy-mm-dd"/>
															</td>
							 							</tr>
														<tr>
							 								<td width="30%">Close Date :</td>
							 								<td width="70%">
																<input type="text" id="closeDate" class="form-control input-sm" placeholder="yyyy-mm-dd"/>
															</td>
							 							</tr>
														<tr>
							 								<td width="30%">Unders :</td>
							 								<td width="70%">
															<div class="form-row">
																<div class="form-group col-md-3">
																	<div class="form-check form-check-inline"><input type="checkbox" id="cb_under_2" value="2" class="form-check-input"><label class="form-check-label" for="cb_under_2">2</label></div>
																	<input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control" id="max_under_2" placeholder="Max. &#8358;">
																</div>
																<div class="form-group col-md-3">
																	<div class="form-check form-check-inline"><input type="checkbox" id="cb_under_3" value="3" class="form-check-input"><label class="form-check-label" for="cb_under_2">3</label></div>
																	<input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control" id="max_under_2" placeholder="Max. &#8358;">
																</div>
																<div class="form-group col-md-3">
																	<div class="form-check form-check-inline"><input type="checkbox" id="cb_under_4" value="4" class="form-check-input"><label class="form-check-label" for="cb_under_2">4</label></div>
																	<input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control" id="max_under_2" placeholder="Max. &#8358;">
																</div>
																<div class="form-group col-md-3">
																	<div class="form-check form-check-inline"><input type="checkbox" id="cb_under_5" value="5" class="form-check-input"><label class="form-check-label" for="cb_under_2">5</label></div>
																	<input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control" id="max_under_2" placeholder="Max. &#8358;">
																</div>
																<div class="form-group col-md-3">
																	<div class="form-check form-check-inline"><input type="checkbox" id="cb_under_6" value="6" class="form-check-input"><label class="form-check-label" for="cb_under_2">6</label></div>
																	<input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control" id="max_under_2" placeholder="Max. &#8358;">
																</div>
																<div class="form-group col-md-3">
																	<div class="form-check form-check-inline"><input type="checkbox" id="cb_under_7" value="7" class="form-check-input"><label class="form-check-label" for="cb_under_2">7</label></div>
																	<input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control" id="max_under_2" placeholder="Max. &#8358;">
																</div>
																<div class="form-group col-md-3">
																	<div class="form-check form-check-inline"><input type="checkbox" id="cb_under_8" value="8" class="form-check-input"><label class="form-check-label" for="cb_under_2">8</label></div>
																	<input type="text" onkeypress="return event.charCode >= 48 && event.charCode <= 57" class="form-control" id="max_under_2" placeholder="Max. &#8358;">
																</div>
																</div>
															</td>
							 							</tr>
							 							<tr>
							 								<td width="30%" style="padding-top:15px">Rule Description :</td>
							 								<td width="70%" style="padding-top:15px"><textarea id="ruleDescription" class="form-control input-sm textarea" style="width:100%" ></textarea></td>
							 							</tr>
							 							
		 											</table>
		 										</td>
		 									</tr>
		 								</table>
	 								</td>
	 							</tr>
	 						</table>	
	 					</div>
	 					</td>
	 				</tr>
	 							
	 				<tr>
	 					<td colspan="3" align="center">
						<div style="padding-top:2px" class="col-md-6">
							<button  type = "button" class="btn btn-success" id="saveButton" onclick="saveOrUpdateCoupon()">Save</button>
							<button  type='button'  class="btn btn-primary" id="updateButton" name="updateButton" onclick="saveOrUpdateCoupon()" disabled style="width:30%">Update</button>
							<button  type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
						</div>
						</td>
	 				</tr>
	 			</table>
				<div class='row'>
					<div class="com-md-5">
						<div class="form-group">
						<!-- Error Message Div -->
							<table border=0 width="80%" align='center'>
								<tr><td colspan=3><div style="margin-left:10%;margin-right:10%width:95%;height:80px;color:red;overflow:auto;display:none" id="error" class="error"></div></td></tr>
							</table>
						<!-- Success Message Div -->
							<table border=0 width="80%" align='center'>
								<tr><td></td></tr>
							</table>
						</div>
					</div>
				</div>
				<input type="hidden" id="idForUpdate" value="0"/>
  				</div>
   			</div>
     	</div>
     </div>
     <input type="hidden" name="id" id="id">
     
 </div>
 <div id="modalInfo" class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalInfoTitle"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p id="modalInfoBody"></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- JS includes -->

<!--<script src="../assets/js/owl.carousel.min.html"></script>
<script src="../assets/js/jquery.magnific-popup.js"></script>
<script src="../assets/js/jquery.easing.1.3.js"></script>
<script src="../assets/css/slick/slick.js"></script>
<script src="../assets/css/slick/slick.min.js"></script>
<script src="../assets/js/jquery.collapse.js"></script>
<script src="../assets/js/bootsnav.js"></script>-->

<!--<script src="../assets/js/plugins.js"></script>
<script src="../assets/js/main.js"></script>
<link href="../assets/css/jquery.multiselect.css" rel="stylesheet" type="text/css">
<script src="../assets/js/jquery.multiselect.js"></script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="../resources/demos/style.css">-->
<script src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
<!--<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="../assets/js/vendor/jquery-3.2.1.slim.min.js"></script>-->
<script src="assets/js/vendor/popper.min.js"></script>
<script src="assets/js/vendor/bootstrap.min.js"></script>

<script src="js/jquery.dataTables.min.js"></script>
<link href="css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
<!-- material datepicker -->
<script type="text/javascript" src="http://momentjs.com/downloads/moment-with-locales.min.js"></script>
<script src="assets/js/vendor/bootstrap-material-datetimepicker.js"></script>
<!--<script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script>
<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>-->
<script src="assets/js/mdtimepicker.js"></script>
<link href="assets/css/mdtimepicker.css" rel="stylesheet" type="text/css">

<script>
  $(document).ready(function(){
	/*$('#matchDate').bootstrapMaterialDatePicker
	({
		format: 'dddd DD MMMM YYYY - HH:mm'
	});*/
	$('#matchDate').bootstrapMaterialDatePicker({ weekStart : 0, time: false }); 
	$('#closeDate').bootstrapMaterialDatePicker({ weekStart : 0, time: false }); 
    
    //$('#matchDateTime').mdtimepicker(); //Initializes the time picker
	
	$('#DataGrid').dataTable({
		"bLengthChange": false,
		"pageLength": 5,
		responsive:true,
	});
  });
  
  function login(){
		$("#loginError").alert('close');
	  	var userName= $('#userName').val();
	  	var password= $('#password').val();
	  	
	  	var form_data = new FormData();
	  	form_data.append("userName", userName);
	  	form_data.append("password", password);
		
		$.ajax({
		    type: "POST",  	
		    url: "<?=$hostname?>/api/login.php",  
		    processData: false,
		    contentType: false,
		    data: form_data,
		    success: function(response){
				response=JSON.parse(response);
		      	if(response.success == "1"){
			    	window.location.href="<?=$hostname?>/";
				}else{
					var html='<div id="loginError" class="alert alert-danger fade show" role="alert" style="width:250px;">'+response.message+'</div>';
					$("#loginErrorContainer").html(html);
					//$("#loginError").show('slow');
				}
			},  
		    error: function(e){  
		      alert(e.status);
	           alert(e.responseText);
	           alert(thrownError);
		    }  
		});  
	  	//document.getElementById("saveButton").disabled=true;
	}  
	
  function edit(sr) {
	    $('#couponDetailModel').modal('show');
		
	  	document.getElementById("saveButton").disabled=true;
	  	document.getElementById("updateButton").disabled=false;
		
		var idForUpdate=$('#idForUpdate_'+sr).val();
		
	  	$('#idForUpdate').val(idForUpdate);
	  	
		var form_data = new FormData();
	  	form_data.append("idForUpdate", idForUpdate);
		$.ajax({
		    type: "POST",  	
		    url: "<?=$hostname?>/api/getCouponData.php",  
		    processData: false,
		    contentType: false,
		    data: form_data,
		    //data: "idForUpdate=" + idForUpdate,  
		    success: function(response){
				response=JSON.parse(response);
		      	if(response.success == "1"){
					$('#weekNo').val(response.week);
					$('#weekInfo').val(response.weekInfo);
					$('#typeId').val(response.typeId);
					$('#minStack').val(response.minStack);
					$('#minPerLine').val(response.minPerLine);
					$('#season').val(response.season);
					$('#matchDate').val(response.matchDate);
					$('#closeDate').val(response.closeDate);
					$('#ruleDescription').val(response.ruleDescription);
					
					$('#error').hide('slow');
				}else{
					$('#error').html(response.message);
					$('#info').hide('slow');
					$('#error').show('slow');
				}
			},  
		    error: function(e){  
		      alert(e.status);
	           alert(e.responseText);
	           alert(thrownError);
		    }  
		});  
	}
	
	function deleteItem(sr) {
		if(confirm('Are you sure you want to delete this Record?')){
			var idForUpdate= $('#idForUpdate_'+sr).val();
			form_data = new FormData();
			form_data.append("pageNumber", pageNumber);
			form_data.append("idForDelete", idForUpdate);
			$.ajax({  
			    type: "POST",  	
			    url: "<?=$hostname?>/deleteInventoryItem.html",  
			    //data: "pageNumber=" + pageNumber+"&idForDelete="+idForDelete,
			    processData: false,
			    contentType: false,
			    data: form_data,
			    success: function(response){
			      	if(response.status == "Success"){
			      		$('#info').html(response.result);
			      		$('#dataTableGrid').html(response.dataGrid);
				    	//$('#dataTable2').html(response.dataGrid);
			      		$('#GeneralMasterDataGrid').dataTable({
			      			"bLengthChange": false,
			    			"pageLength": 4,
			    			responsive:true,
			    		});
					}
			      	else{
						$('#error').html(response.result);
						$('#info').hide('slow');
						$('#error').show('slow');
					}
				},  
			    error: function(e){  
			      alert('Error: ' + e);  
			    }  
			});  
		 }
	}
	function addNew() {
	  $('#couponDetailModel').modal('show');
		//$('#itemText').val($('#name_'+formFillForEditId).html());
		
	  	//document.getElementById("saveButton").disabled=true;
	  	//document.getElementById("updateButton").disabled=false;
		
	  	$('#idForUpdate').val("0");
		
		document.getElementById("saveButton").disabled=false;
	  	document.getElementById("updateButton").disabled=true;
	}
</script>

<script>
$(":radio").change(function(){
	var teamValue = jQuery('input[name=team]:checked').val();
	$.ajax({
	 type : 'post',
	 url : 'memberNameValue.php',
	 data : {teamValue:teamValue},
	success : function(data)
	{
		$('#members').html(data);
	}
	});
});	
</script>
		
		
    </body>

</html>
